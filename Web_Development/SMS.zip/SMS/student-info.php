<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Information</title>

  <style>
    html{
    font-family: var(--ff-primary);
    }

    body{
    width: 100%;
    margin: 0 0;
    }

    :root{
  --color--primary--100: #635DF7 ;
  --color--primary--200: white;
  --color--primary--300: orange;

  --ff-primary: "Poppins" , sans-serif;
    }

    main{
      height: 100vh;
      background-color: var(--color--primary--100);
      padding: 10px 10px;
    }
    .container{
      display: grid;
      grid-template-rows: 20% 40% 40%;
      height:670px;
      background-color: var(--color--primary--200);
      border-radius: 24px;
    }

    .header{
      padding: 20px 10px;
      border: solid 1px;
      border-top: none;
      border-left: none;
      border-right: none;
    }

    .profile{
      display: grid;
      grid-template-columns: 40% 60%;
      flex-direction: column;  
    }

    .img-container{
      width: 200px;
      height: 200px;
      padding-left: 60%;
      padding-top: 30px;
      padding-bottom: 30px;
      }

    .img{
      overflow: hidden;
      border: solid 4px var(--color--primary--100);
    }

    img{
      width:200px;
      height: 200px;
      object-fit: cover;
    }

    .basic-info{
      padding: 30px 10px;
      line-height: 35px;
    }

    .info{
      padding-left: 24%;
      padding-top: 30px;
      line-height: 35px;
      padding-right: 400px;
    }

    h4{
      margin: 0 0;
      font-size: 16px;
    }

   h5{
    background-color: #f9f9f9;;
    padding: 0 15%;
    margin: 0 0;
    border: solid 1px lightblue;
   }

   h5:hover{
    background-color: lightblue;
   }

   .header{
    display: flex;
   }

   .actions{
    width: 200px;
    margin-left: 60%;
    height: 20px;
    margin-top: 60px;
    display: flex;
    justify-content: space-between;
   }

   a{
      text-align: center;
      border: solid;
      background-color: orange;
      color: white;
      align-content: space-between;
      font-size: 1rem;
      padding: 2px 8px;
      text-decoration: none;
      border-radius: 8px;
    }

    a:hover{
      opacity: 0.8;
    }

    .delete-btn:hover{
      background-color: red;  
    }

    .update-btn:hover{
      background-color: green;
    }
   
  </style>
</head>
<body>
  <main>
    <div class="container">
    <?php
        session_start();
        include("database_connection/database.php");
        
        if (isset($_GET['delete-student'])) {
            $student_id = intval($_GET['delete-student']); // Ensure the ID is an integer
        
            // Step 1: Fetch the student details before deletion
            $sql = "SELECT * FROM student WHERE student_id = $student_id";
            $result = mysqli_query($conn, $sql);
        
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        
                // Extract student details
                $fname = mysqli_real_escape_string($conn, $row['first_name']);
                $lname = mysqli_real_escape_string($conn, $row['last_name']);
        
                // Step 2: Insert log into the recent_activity table
                $logsql = "INSERT INTO recent_activity (activity) 
                           VALUES ('Deleted Student: $fname $lname')";
                if (!mysqli_query($conn, $logsql)) {
                    die("Error logging activity: " . mysqli_error($conn));
                }
            } else {
                die("Student not found or error fetching details: " . mysqli_error($conn));
            }
        
            // Step 3: Delete the student record
            $delete_sql = "DELETE FROM student WHERE student_id = $student_id";
            if (!mysqli_query($conn, $delete_sql)) {
                die("Error deleting student: " . mysqli_error($conn));
            }
        
            // Step 4: Redirect to the students page
            header("Location: students.php");
            exit();
        }
        
        
        if(isset($_GET['view-student'])){
        $student_id = $_GET['view-student'];

        $sql = "SELECT * FROM student WHERE student_id = $student_id";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($result)){ ?>
      <div class="header">
        <h1>Student Info | Profile</h1>
        <div class="actions">
          <?php if($_SESSION['user_info_user_type']=== "admin"){
            echo '<div class="action">';
            echo '<a class="update-btn" href="update.php?update-student=' . $row['student_id'] . '">Update</a>';
            echo '<a class="delete-btn" href="student-details.php?delete-student=' . $row['student_id'] . '">Delete</a>';
            echo '</div>';
          }
        ?>
        </div>
      </div>
      <div class="profile">
        <div class="img-container">
            <div class="img">
                <?php echo  '<img src="' . $row['student_image'] . ' " alt="Student Profile">' ?>
            </div>
        </div>
        <div class="basic-info">
          <tr>
            <h4><td><?php echo " <span>Fullname:</span> " . $row['first_name'] . " " . $row['last_name']; ?></td> <br></h4>
            <h4><td><?php echo " <span>Student ID:</span> " . $row['student_id']; ?></td> <br></h4>
            <h4><td><?php echo " <span>Program:</span> " . $row['program']; ?></td> <br></h4>
            <h4><td><?php echo " <span>Year:</span> " . $row['year']; ?></td> <br></h4>  
          </tr>
        </div>
      </div>
      <div class="info">
        <tr>
          <h5><td><?php echo " <span>Date of Birth:</span> " . $row['birth_date']; ?></td> </h5>
          <h5><td><?php echo " <span>Gender:</span> " . $row['gender']; ?></td> </h5>
          <h5><td><?php echo " <span>Address:</span> " . $row['address']; ?></td> </h5>
        </tr>
        <?php }
      }
      ?>
      </div>
    </div>
  </main>
</body>
</html>