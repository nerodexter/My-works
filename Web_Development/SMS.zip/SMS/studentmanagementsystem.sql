-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2024 at 09:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `recent_activity`
--

CREATE TABLE `recent_activity` (
  `id` int(11) NOT NULL,
  `activity` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recent_activity`
--

INSERT INTO `recent_activity` (`id`, `activity`, `timestamp`) VALUES
(1, 'Added new student: Alden Richards, Program: BS Information Technology, Year: 3.', '2024-12-13 07:51:28'),
(2, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 4.', '2024-12-13 07:52:46'),
(3, 'Updated student: Paulo Avelino (ID: 17).', '2024-12-13 07:53:05'),
(4, 'Added new student: Alden Richards, Program: BS Psychology, Year: 3.', '2024-12-13 07:53:46'),
(5, 'Added new student: Alden Richards, Program: BS Information Technology, Year: 3.', '2024-12-13 07:58:33'),
(6, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-13 08:04:31'),
(7, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-13 08:07:20'),
(8, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-13 08:11:47'),
(9, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-15 05:35:36'),
(10, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-15 05:42:36'),
(11, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-15 05:47:53'),
(12, 'Updated student: Paulo Avelino (ID: 25).', '2024-12-15 05:48:12'),
(13, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 4.', '2024-12-15 05:51:41'),
(14, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-15 06:04:09'),
(15, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 4.', '2024-12-15 06:07:48'),
(16, 'Added new student: Paulo Richards, Program: BS Information Technology, Year: 4.', '2024-12-16 02:35:07'),
(17, 'Updated student: Paulo Avelino (ID: 29).', '2024-12-16 02:36:12'),
(18, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-16 03:35:20'),
(19, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-16 03:39:23'),
(20, 'Updated student: Paulo Avelino (ID: 1).', '2024-12-16 03:46:07'),
(21, 'Added new student: Alden Richards, Program: BS Information Technology, Year: 3.', '2024-12-16 03:51:53'),
(22, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-16 04:33:07'),
(23, 'Updated student: Paulo Avelino (ID: 3).', '2024-12-16 04:36:35'),
(24, 'Added new student: Paulo Avelino, Program: BS Information Technology, Year: 3.', '2024-12-16 04:54:50'),
(25, 'Updated student: Paulo Avelino (ID: 4).', '2024-12-16 04:55:56');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(500) NOT NULL,
  `last_name` varchar(500) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `program` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `student_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `first_name`, `last_name`, `birth_date`, `gender`, `address`, `program`, `year`, `date_added`, `student_image`) VALUES
(1, 'Paulo', 'Avelino', '1991-01-21', 'Male', 'Etivac', 'BS Information Technology', 4, '2024-12-16 11:39:23', 'img/paulo-removebg-preview.png'),
(2, 'Alden', 'Richards', '1993-03-23', 'Male', 'Isla Puting Bato', 'BS Information Technology', 3, '2024-12-16 11:51:53', 'img/Alden.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `access` varchar(50) NOT NULL DEFAULT 'student',
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `email`, `password`, `access`, `date_added`) VALUES
(7, 'admin', 'admin@gmail.com', 'admin2', 'admin', '2024-12-01 13:34:51'),
(13, 'dexter', 'dexter26@gmail.com', 'dexter123', 'student', '2024-12-16 12:42:51'),
(14, 'user', 'user@gmail.com', 'user123', 'student', '2024-12-16 12:58:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `recent_activity`
--
ALTER TABLE `recent_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `recent_activity`
--
ALTER TABLE `recent_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
