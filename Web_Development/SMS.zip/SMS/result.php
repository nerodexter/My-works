<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Result</title>

  <style>
     body{
      font-family: var(--ff-primary);
      background-color: var(--color--primary--100);
    }

    .html{
      font-family: var(--ff-primary);
    }

    :root{
  --color--primary--100: #635DF7;
  --color--primary--200: white;
  --color--primary--300: orange;

  --ff-primary: "Poppins" , sans-serif;

   }

    .containter{
      display: grid;
      grid-template-columns: 100%;
      height: 100vh;
      width: 100%;
    }

    .main-content{
      margin: 10px 10px;
      border-radius: 24px;
      padding: 0 15px;
      padding: 20px 25px;
      background-color: var(--color--primary--200) ;
      height: 643px;
    }

    table{
  border-collapse: collapse;
  width: 100%;
  margin-bottom: 20px;
}

th, td{
  border: solid 1px #ddd;
  padding: 10px;
  text-align: left;
}

th{
  background-color: rgb(4, 4, 105);
  
  color: white;
}

tr:nth-child(even){
  background-color: #f9f9f9;
}

tr:hover{
  background-color: #f2f2f2;
}

.view-details{
  color: blue;
}

.data{
  overflow: scroll;
}
  </style>
</head>
<body>
  <div class="container">
  <main class="main-content">
        <h1 class="title">Student List</h1>
          <br>
        <?php
          include_once("database_connection/database.php");

          $search = $_GET['search'];
          $sql = "SELECT * FROM student WHERE first_name LIKE '$search%' OR last_name LIKE '$search%' ORDER BY student_id DESC";
          $students = mysqli_query($conn,$sql); ?>
            
          <div class="data">
              <table>
                  <thead>
                    <tr>
                      <th>First Name</th>
                      <th>Last Name</th>
                    </tr>
                  </thead>
             <?php while($row = mysqli_fetch_assoc($students)){ ?>
                  <tbody>
                    <tr>
                      <td><?php echo $row['first_name']; ?></td>
                      <td><?php echo $row['last_name']; ?></td>
                      <td><a class="view-details" href="student-info.php?view-student=<?php echo $row['student_id']; ?>">View</a></td>
                    </tr>
                  </tbody>
                  <?php
                  }
                  ?>
                  </table>
          </div>
      </main>
  </div>
</body>
</html>