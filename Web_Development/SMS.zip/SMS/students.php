<?php include("database_connection/database.php"); 
  session_start();

  if(isset($_GET['logout'])){
    session_destroy();
    header("Location: ./signin/signin.php");
    exit();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
  <link rel="stylesheet" href="student.css">
</head>
<body>
    <div class="container">
      <div class="sidebar">
          <div class="title-logo">
            <h1>Student Management System</h1>
            <p>Efficiently manage student records, <br> track progress, and oversee academic <br> activities  with ease.</p>
          </div>
          <div class="navlinks">
              <ul>
              <div class="icon">
                <img class="dshbrd-img" src="img/dashboard-removebg-preview.png" alt="">
                <li><a href="index.php">Dashboard</a></li>
                </div>
                <div class="icon">
                  <img src="img/student-logo.webp" alt="">
                <li><a href="students.php">Students</a></li>
                </div>
              </ul>
          </div>
          <div class="logout-container">
           <button class="logout-btn"> <a href="?logout">Logout</a></button> 
          </div>
      </div>
      <main class="main-content">
        <div class="main-container">
          <div class="header">
            <div class="title">
              <h1 class="title">Student List</h1>
              <?php if($_SESSION['user_info_user_type'] === "admin"){
                echo  '<div class="add-new"> <a href="add.php">Add New</a> </div>';
              } ?>
            </div>
            <div class="search-bar">
              <form action="result.php" method="get">
                <input class="search-field" type="text" name="search" id="search" placeholder="search student">
                <button class="search-btn" type="submit"><img class="search-icon" src="img/search-icon.png" alt="search"></button>
             </form>
            </div>
          </div>
          <div class="student-table">

            <?php
            include_once("database_connection/database.php");

            $sql = "SELECT * FROM student ORDER BY student_id DESC";
            $students = mysqli_query($conn,$sql); ?>
            
            <div class="data">
              <table>
                  <thead>
                    <tr>
                      <th>First Name</th>
                      <th>Last Name</th>
                    </tr>
                  </thead>
             <?php while($row = mysqli_fetch_assoc($students)){ ?>
                  <tbody>
                    <tr> 
                      <td><?php echo $row['first_name']; ?></td>
                      <td><?php echo $row['last_name']; ?></td>
                      <td><a class="view-details" href="student-info.php?view-student=<?php echo $row['student_id']; ?>">View</a></td>
                    </tr>
                  </tbody>
                  <?php
                    }
                  ?>
              </table>
            </div>

          </div>
        </div>
      </main>
  </div>
</body>
<script src="add.js"></script>
</html>



            
          
          