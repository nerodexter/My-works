document.addEventListener("DOMContentLoaded" , event=> {
  const addButton = document.querySelector(".add-button");
  const addContent = document.querySelector(".add-content");

  addButton.addEventListener("click", event=> {
    addContent.style.display = addContent.style.display === "block" ? "none" : "block";
  });
  
  window.addEventListener("click", event=> {
    if (!event.target.matches('.add-button')) {
      if (addContent.style.display === "block") {
        addContent.style.display = "none";
      }
    }
  });
});
