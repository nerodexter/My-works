<?php
    
    include_once("database_connection/database.php");
    session_start();

        $student_id = $_GET['update-student'];
        $sql = "SELECT * FROM student WHERE student_id = $student_id";
        $result = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result); 

        if(isset($_POST['submit'])){
            
            $student_id = $_GET['update-student'];
            $fname = $_POST['firstname'];
            $lname = $_POST['lastname'];
            $birthday = $_POST['birth_day'];
            $gender = $_POST['gender'];
            $address = $_POST['address'];
            $program = $_POST['program'];
            $year = $_POST['year'];

            $targetDirectory = "img/"; 
            $targetFile = $targetDirectory . basename($_FILES["student_image"]["name"]); // Full path to the uploaded file
    
        
            if (move_uploaded_file($_FILES["student_image"]["tmp_name"], $targetFile)) {
            echo "The file ". basename( $_FILES["student_image"]["name"]). " has been uploaded.";

             $sql = "UPDATE student SET 
                                   first_name = '$fname' , 
                                   last_name = '$lname', 
                                   address = '$address', 
                                   program = '$program' , 
                                   year = '$year', 
                                   student_image = '$targetFile' 
                     WHERE student_id = '$student_id'";

            if(mysqli_query($conn,$sql)){
            $activity = "Updated student: $fname $lname (ID: $student_id).";
            $logSql = "INSERT INTO `recent_activity` (`activity`) VALUES ('$activity')";
                mysqli_query($conn,$logSql);
                echo header ("Location: students.php");
                die();
            }   
        }
    
            else{
                echo "error updating student" . mysqli_error($conn);
            }
        }
    ?>

<!DOCTYPE html>
<html lang="eng">
<head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <title>Student Management System</title>
            <link rel="stylesheet" href="css/style.css">

<style>
    body{
      font-family: var(--ff-primary);
      background-color: var(--color--primary--100);
    }

    .html{
      font-family: var(--ff-primary);
    }

    :root{
  --color--primary--100: #635DF7;
  --color--primary--200: white;
  --color--primary--300: orange;

  --ff-primary: "Poppins" , sans-serif;

   }

    .containter{
      display: grid;
      grid-template-columns: 100%;
      height: 100vh;
      width: 100%;
    }

    main{
      margin: 10px 10px;
      border-radius: 24px;
      padding: 0 15px;
      padding: 20px 25px;
      background-color: var(--color--primary--200) ;
      height: 643px;
    }

    form{
    display: flex;
    flex-direction: column;
    line-height: 15px;
    }

    label{
    font-weight: bold;
    font-size: 16px;
    }

    input{
    border-radius: 8px;
    border: solid 1px;
    padding: 8px 8px;
    outline: none;
    }

    input:hover{
    border-radius: 8px;
    border: solid 1px;
    padding: 8px 8px;
    outline: none; 
    border-color: var(--color--primary--100);
    }

    select{
    border-radius: 8px;
    border: solid 1px;
    padding: 8px 8px;
    outline: none;
    }

    select:hover{
    border-radius: 8px;
    border: solid 1px;
    padding: 8px 8px;
    outline: none; 
    border-color: var(--color--primary--100);
    }
    

    .submit-btn{
        display: flex;
        justify-content: center;
    }

    input[type='submit']{
        width: 60%;
        border: none;
        background-color: var(--color--primary--300);
        color: white;
        padding: 7px 0;
    }
    input[type='submit']:hover{
        opacity: 0.8;
        width: 60%;
        border: none;
        background-color: var(--color--primary--300);
        color: white;
    }
</style>


</head>

<body>
    <div class="container">
        <main>
            <div class="update-student">
                <h1>Update Student</h1>
            </div>
            <form action="" method="post" enctype="multipart/form-data">
    
    <label>Student Profile:</label>
    <input type="file" id="student_image" name="student_image" accept="image/*" <?php echo $row['student_image']; ?> required> <br>

    <label>First Name</label>
    <input type="text" name="firstname" id="firstname" value="<?php  echo $row['first_name']; ?>"> <br>

    <label>Last Name</label>
    <input type="text" name="lastname" id="lastname" value="<?php  echo $row['last_name']; ?>"> <br>

    <label>Birthday:</label>
    <input type="date" name="birth_day" value="<?php  echo $row['birth_date']?>" aria-readonly="true"> <br>

    <label>Gender:</label>
    <select name="gender" id="gender" aria-readonly="true">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select> <br>

    <label>Address:</label>
    <input type="text" name="address" value="<?php  echo $row['address'] ?>"> <br>

    <label>Program:</label>
    <input type="text" name="program" value="<?php  echo $row['program'] ?>"> <br>

    <label>Year:</label>
    <input type="text" name="year" value="<?php  echo $row['year'] ?>"> <br>
    <div class="submit-btn">
        <input type="submit" name="submit" value="Update">
    </div>
    </form>
        </main>
    </div>
</body>
</html>