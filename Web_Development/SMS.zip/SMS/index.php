<?php include("../SMS/database_connection/database.php");
  session_start();

if(!isset($_SESSION['user_info_id'])){
  header("Location: ./signin/signin.php");
  die();
}

  if(isset($_GET['logout'])){
    session_destroy();
    header("Location: ./signin/signin.php");
    die();
  }

  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard</title>
  <link rel="stylesheet" href="index.css">
</head>
<body>
  <div class="container">
  <div class="sidebar">
          <div class="title-logo">
            <h1>Student Management System</h1>
            <p>Efficiently manage student records, <br> track progress, and oversee academic <br> activities  with ease.</p>
          </div>
          <div class="navlinks">
              <ul>
                <div class="icon">
                <img class="dshbrd-img" src="img/dashboard-removebg-preview.png" alt="">
                <li><a href="index.php">Dashboard</a></li>
                </div>
                <div class="icon">
                  <img src="img/student-logo.webp" alt="">
                <li><a href="students.php">Students</a></li>
                </div>
              </ul>
          </div>
          <div class="logout-container">
           <button class="logout-btn"> <a href="?logout">Logout</a></button> 
          </div>
      </div>
      <main class="main-content">
    <div class="div1">
        <h1 style="font-size: 40px;">Welcome <?php echo $_SESSION['user_info_username'] . "!" ?></h1>
    </div>
    <div class="div2">
        <div class="div2_1">
          <h2>Students</h2>
          <div class="img-container">
              <img class="image" src="img/student-logo.webp" alt="">
              <?php
                $sql = "SELECT COUNT(student_id) as total_student FROM student";
                $result = mysqli_query($conn,$sql);
                $row = mysqli_fetch_assoc($result);
                $total_student = $row['total_student'];
              ?>
              <h3><span style="font-weight:lighter">Total Students:</span> <?php echo htmlspecialchars($total_student) ?></h3>
          </div>
        </div>
        <div class="div2_2">
          <?php
        $query = "SELECT activity, timestamp FROM recent_activity ORDER BY timestamp DESC LIMIT 5";
        $result = mysqli_query($conn, $query);
        ?>
          <div class="activity-log">
            <h1>Recent Activity</h1>
              <?php while ($row = mysqli_fetch_assoc($result)) { ?>
              <div class="activity-item">
                <p><?php echo $row['activity']; ?></p>
                <p class="timestamp"><?php echo $row['timestamp']; ?></p>
              </div>
              <?php } ?>
          </div>
        </div>
    </div>
  </main>
  </div>
</body>
</html>