<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>

  <style>
    body{
      font-family: var(--ff-primary);
      background-color: var(--color--primary--100);
    }

    .html{
      font-family: var(--ff-primary);
    }

    :root{
  --color--primary--100: #635DF7;
  --color--primary--200: white;
  --color--primary--300: orange;

  --ff-primary: "Poppins" , sans-serif;

   }

    .containter{
      display: grid;
      grid-template-columns: 100%;
      background-color: var(--color--primary--100);
      height: 100vh;
      width: 100%;
    }

    main{
      margin: 10px 10px;
      border-radius: 24px;
      padding: 0 15px;
      padding: 20px 20px;
      background-color: var(--color--primary--200) ;
    }

    .title{
      font-size: 32px;
      text-align: center;
    }
    
    h2{
      font-size: 18px;
      font-weight: lighter;
      text-align: center;
    }

    span {
      font-weight: bold;
    }

    .student-profile{
      text-align: center;
      display: flex;
      justify-content: center; 
      height: 140px;
    }

    .img-container{
      width: 140px;
      height: 140px;
      border-radius: 50%;
      overflow: hidden;
      border: solid 1px;
    }

    img{
      width: 150px;
      object-fit:cover;
    }

  
    .student-info-container{
      display: grid;
      width: 60%;
      margin: 3% 20%;
      box-shadow: 0px 0px 8px black;
      border-radius: 10px;
      padding-bottom: 20px;
    }

    .student-details{
      width: 100%;
      padding: 10px 0;
    }

    .action{
      display: flex;
      justify-content: center;
    }

    a{
      text-align: center;
      border: solid;
      background-color: orange;
      color: white;
      align-content: space-between;
      font-size: 1.2rem;
      padding: 5px 8px;
      text-decoration: none;
      border-radius: 8px;
    }

    a:hover{
      opacity: 0.8;
    }

  </style>

</head>
<body>
  <div class="container">
  <main>
    <a href="students.php">Back</a>
    <div class="student-info-container">
      <div class="student-details">
      <h1 class="title">Student Information</h1>
      <?php
        session_start();
        include("database_connection/database.php");


        if(isset($_GET['delete-student'])){
          $student_id = $_GET['delete-student'];

          $sql = "DELETE FROM student WHERE student_id = $student_id";
          mysqli_query($conn,$sql);
          header("Location: students.php");
        }

        if(isset($_GET['view-student'])){
        $student_id = $_GET['view-student'];

        $sql = "SELECT * FROM student WHERE student_id = $student_id";
        $result = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($result)){ ?>
      <div class="student-profile">
        <div class="img-container">
          <?php echo  '<img src="' . $row['student_image'] . ' " alt="Student Profile">' ?>
        </div>  
      </div>
        <h2><?php echo " <span>Fullname:</span> " . $row['first_name'] . " " . $row['last_name']; ?></h2>
        <h2><?php echo " <span>Date of Birth:</span> " . $row['birth_date']; ?></h2>
        <h2><?php echo " <span>Gender:</span> " . $row['gender']; ?></h2>
        <h2><?php echo " <span>Address:</span> " . $row['address']; ?></h2>
        <h2><?php echo " <span>Program:</span> " . $row['program']; ?></h2>
        <h2><?php echo " <span>Year:</span> " . $row['year']; ?></h2>
        <?php if($_SESSION['user_info_user_type']=== "admin"){
          echo '<div class="action">';
          echo '<a href="update.php?update-student=' . $row['student_id'] . '">Update</a>';
          echo '<a href="student-details.php?delete-student=' . $row['student_id'] . '">Delete</a>';
          echo '</div>';
        }
        ?>
        <?php
          }
        }
      ?>
      
      </div>
    </div>
  </main>
  </div>
</body>
</html>