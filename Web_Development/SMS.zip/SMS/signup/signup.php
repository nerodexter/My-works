<?php
  include("../database_connection/database.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
  <main>
    <div class="container">
      <div class="Sideimage">
        <img src="sideimg.png" alt="Sideimage" class="sideimagebg">
      </div>
      <div class="signup">
        <div class="about">
            <h1>Student Management System</h1>
        </div>
        <div class="signup">
          <h1><span>Sign up</span></h1>
        </div>
        <form action="signup-process.php" method="post">
          <label for="username">Username:</label>
          <input type="text" name="username" required>
          <br>
          <label for=""email>Email:</label>
          <input type="email" name="email" required> 
          <br>
          <label for="userpass">Password:</label>
          <input type="password" name="userpass" required>
          <br>
          <div class="signup-action">
          <input type="submit" name="submit" value="Create Account">
          </div>
          <div class="link">
          <p>Already have an account? <a href="../signin/signin.php">Login</a></p>
          </div>
        </form>
      </div>
    </div>
  </main>
</body>
</html>