<?php
  include("../database_connection/database.php");
  if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['userpass'];
    $access = $_POST['access'];

    $check_user_query  = "SELECT * FROM user WHERE username = ?"; // writing a statement
    $statement = mysqli_prepare($conn,$check_user_query); //prepare the statement
    mysqli_stmt_bind_param($statement, "s", $username); // fill in the blank space (?) with the username the person is trying to use. The "s" tells the system that the blank will be filled with a "string" (a word or text).
    mysqli_stmt_execute($statement); // execute the statement and check if this username exist 
    $result = mysqli_stmt_get_result($statement); // get the result and stores in container

    if(mysqli_num_rows($result)> 0){ // if the result is more than 0 mean username already exist 
      header("Location: signup/signup.php>message=user already exist");
      die();
    }
    else{
    $sql = "INSERT INTO user(username, email, password) 
                         VALUES('$username' , '$email', '$password')";
    $result = mysqli_query($conn,$sql);

    header("Location: ../signin/signin.php?user created succesfully");
    die();
  }

}

  mysqli_close($conn);

?>