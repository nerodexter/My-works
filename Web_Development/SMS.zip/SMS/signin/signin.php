<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signin</title>
  <link rel="stylesheet" href="signin.css">
</head>
<body>
  <main>
    <div class="container">
      <div class="signin">
        <div class="about">
            <h1>Student Management System</h1>
        </div>
        <div class="signin-h1">
        <h1><span>Login</span></h1>
        </div>
        <form action="signin-process.php" method="post">
          <p style="color: red; text-align: center;">
            <?php if(isset($_GET['error'])){ 
              echo "Wrong Credentials . <br> "; 
              echo htmlspecialchars($_GET['error']); 
            }
            ?>
          </p>
          <label for="username">Username:</label>
          <input type="text" name="username">
          <br>
          <label for="userpass">Password:</label>
          <input type="password" name="userpass">
          <br>
          <div class="signin-action">
          <input type="submit" value="Login" name="submit">
          </div>
          <div class="link">
          <p>Are you new? <a href="../signup/signup.php">Sign up</a></p>
          </div>
        </form>
      </div>
      <div class="sideimage">
        <img src="sideimg.png" alt="sideimage" class="image">
      </div>
    </div>
  </main>
</body>
</html>