<?php
  include("../database_connection/database.php");
  session_start();
?>
<?php
  if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = $_POST['userpass'];

    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $get_result = mysqli_query($conn,$sql);
    $count_result = mysqli_num_rows($get_result);

    if($count_result > 0){
      $row = mysqli_fetch_assoc($get_result);
        
      //create session variables
      $_SESSION['user_info_id'] = $row['user_id'];
      $_SESSION['user_info_username'] = $row['username'];
      $_SESSION['user_info_email'] = $row['email'];
      $_SESSION['user_info_password'] = $row['password'];
      $_SESSION['user_info_user_type'] = $row['access'];
      header("Location: ../index.php?message=login successfully");
      die(); 
    } 
   else{
      header("Location: ../signin/signin.php?error=invalid username or password");
      exit();
    }

    mysqli_close($conn);
    
  }

?>

